package jobportal;

public interface CandidateInterface {
	void addCandidateDetails() throws Exception;
	void viewCandidates() throws Exception;
	void updateCandidateDetails(int companyId) throws Exception;
	void deleteCandidateDetails(int candidateId) throws Exception;
	void applyFilterToCandidates() throws Exception;
}
