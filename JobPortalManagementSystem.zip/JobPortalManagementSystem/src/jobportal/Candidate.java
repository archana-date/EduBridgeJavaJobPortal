package jobportal;

import java.io.Serializable;

public class Candidate implements Serializable{
	private int candidateId;
	private String candidateName;
	private String candidateAddress;
	private String candidatePhoneNo;
	private String candidateEmail;
	private String candidateEducation;
	private int candidateExperience;
	private String candidateLanguageKnown;
	private String candidatePreference;
	
	public Candidate() {
		
	}
	
	public Candidate(int candidateId, String candidateName, String candidateAddress, String candidatePhoneNo,
			String candidateEmail,String candidateEducation, int candidateExperience,String candidateLanguageKnown,String candidatePreference) {
		super();
		this.candidateId = candidateId;
		this.candidateName = candidateName;
		this.candidateAddress = candidateAddress;
		this.candidatePhoneNo = candidatePhoneNo;
		this.candidateEmail = candidateEmail;
		this.candidateEducation = candidateEducation;
		this.candidateExperience = candidateExperience;
		this.candidateLanguageKnown = candidateLanguageKnown;
		this.candidatePreference = candidatePreference;
	}

	public int getCandidateId() {
		return candidateId;
	}

	public void setCandidateId(int candidateId) {
		this.candidateId = candidateId;
	}

	public String getCandidateName() {
		return candidateName;
	}

	public void setCandidateName(String candidateName) {
		this.candidateName = candidateName;
	}

	public String getCandidateAddress() {
		return candidateAddress;
	}

	public void setCandidateAddress(String candidateAddress) {
		this.candidateAddress = candidateAddress;
	}

	public String getCandidatePhoneNo() {
		return candidatePhoneNo;
	}

	public void setCandidatePhoneNo(String candidatePhoneNo) {
		this.candidatePhoneNo = candidatePhoneNo;
	}

	public String getCandidateEmail() {
		return candidateEmail;
	}

	public void setCandidateEmail(String candidateEmail) {
		this.candidateEmail = candidateEmail;
	}

	

	public String getCandidateEducation() {
		return candidateEducation;
	}

	public void setCandidateEducation(String candidateEducation) {
		this.candidateEducation = candidateEducation;
	}

	public int getCandidateExperience() {
		return candidateExperience;
	}

	public void setCandidateExperience(int candidateExperience) {
		this.candidateExperience = candidateExperience;
	}

	public String getCandidateLanguageKnown() {
		return candidateLanguageKnown;
	}

	public void setCandidateLanguageKnown(String candidateLanguageKnown) {
		this.candidateLanguageKnown = candidateLanguageKnown;
	}

	public String getCandidatePreference() {
		return candidatePreference;
	}

	public void setCandidatePreference(String candidatePreference) {
		this.candidatePreference = candidatePreference;
	}

	@Override
	public String toString() {
		return  candidateId + " " + candidateName + " "+ candidateAddress + " " + candidatePhoneNo + " " + candidateEmail
				+ " " + candidateEducation + " "
				+ candidateExperience + " " + candidateLanguageKnown + " "+ candidatePreference;
	}
	
	
	

}
