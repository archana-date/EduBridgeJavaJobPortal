package jobportal;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.Serializable;
import java.util.Scanner;



public class TestJobPortal implements Serializable {

	public static void main(String[] args) throws Exception{
		Scanner scanner = new Scanner(System.in);
		// TODO Auto-generated method stub
		int ch1;
		int op;
		int op1;
		do
		{
		       System.out.println("1: Admin  ");
		       System.out.println("2: Company  ");
		       System.out.println("3: Candidate ");
		       System.out.println("0: EXIT Main Menu");
		       System.out.println("Enter option of your choice");
		       BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(System.in));
		       op = Integer.parseInt(bufferedReader.readLine());
		       switch(op)
		       {
		       case 1:
		    	   int ch;
		    	   do {
		    		   System.out.println("1: Add Admin  ");
			           System.out.println("2: Update Admin");
			           System.out.println("3: View Admin ");
			           System.out.println("4: Delete Admin");
			    	   System.out.println("5: View Companies  ");
			           System.out.println("6: Delete Company");
			           System.out.println("7: View Candidates ");
			           System.out.println("8: Delete Candidate");
			           System.out.println("0: EXIT ADMIN");
		           
		           System.out.println("Enter option of your choice");
		           op1 = Integer.parseInt(bufferedReader.readLine());
		               switch(op1)
		               {
		               case 1:
		            	   AdminInterface adminInterface = new AdminInterfaceImpl();
		            	   adminInterface.addAdmin();
		            	   break;
		               case 2:
		            	   System.out.println("Enter Admin's ID to update");
		            	   int adId = scanner.nextInt();
		            	   AdminInterface adminInterface1 = new AdminInterfaceImpl();
		            	   adminInterface1.updateAdmin(adId);
		            	   break;
		               case 3:
		            	   AdminInterface adminInterface2 = new AdminInterfaceImpl();
		            	   adminInterface2.viewAdmin();
		            	   break;
		               case 4:
		            	   System.out.println("Enter Admin's ID to delete");
		            	   int adId1 = scanner.nextInt();
		            	   AdminInterface adminInterface3 = new AdminInterfaceImpl();
		            	   adminInterface3.deleteAdmin(adId1);
		            	   break;
		               case 5:
		            	   CompanyInterface companyInterface1 = new CompanyInterfaceImpl();
		            	   companyInterface1.viewCompanies();		            	   
		               break;
		               case 6:
		            	   System.out.println("Enter Company's ID to Delete");
		       				int comId = scanner.nextInt();
		       			 CompanyInterface companyInterface2 = new CompanyInterfaceImpl();
		            	   companyInterface2.deleteCompanyDescription(comId);
		            	   
		               break;
		               case 7:
		            	   CandidateInterface candidateInterface1 = new CandidateInterfaceImpl();
		            	   candidateInterface1.viewCandidates();
		               break;
		               case 8:
		            	   	System.out.println("Enter Candidate's ID to Delete");
		       				int canId = scanner.nextInt();
		       				CandidateInterface candidateInterface2 = new CandidateInterfaceImpl();
		       				candidateInterface2.deleteCandidateDetails(canId);
		       				
		               break;
		               default:
		            	   if(op1 == 0) {
		            		   System.out.println("Admin Module Terminated");
		            	   }
		            	   else
		            	   System.out.println("Invalid Option");	               		               
		               }	
		            }while(op1!=0);		    	   
		    	   break;
		    	   
		       case 2: 
		    	   do {
					
		    		   System.out.println("1: Add Company Description  ");
		    		   System.out.println("2: Update Company Description");
		    		   System.out.println("3: Delete Company");
			           System.out.println("4: Add Job Description  ");
			           System.out.println("5: Update Job Description ");
			           System.out.println("6: Delete Job Description");
			           System.out.println("7: View all Candidates");
			           System.out.println("8: View Eligible Candidates by applying filters");
			           System.out.println("0: EXIT COMPANY");
		           
		           System.out.println("Enter option of your choice");
		           op1 = Integer.parseInt(bufferedReader.readLine());
		               switch(op1)
		               {
		               case 1:
		            	   CompanyInterface companyInterface1 = new CompanyInterfaceImpl();
		            	   companyInterface1.addCompanyDescription();
		               break;
		               case 2:
		            	   System.out.println("Enter Company's ID to Update");
		       				int compId = scanner.nextInt();
		       				CompanyInterface companyInterface3 = new CompanyInterfaceImpl();
		            	   companyInterface3.updateCompanyDescription(compId);
		            	   
		               break;
		               case 3:
		            	   System.out.println("Enter Company's ID to Delete");
		       				int comId = scanner.nextInt();
		       				CompanyInterface companyInterface2 = new CompanyInterfaceImpl();
		            	   companyInterface2.deleteCompanyDescription(comId);
		               break;
		               case 4:
		            	  JobInterface jobInterface = new JobInterfaceImpl();
		            	  jobInterface.addJobDetails();
		               break;
		               case 5:
		            	   System.out.println("Enter Job's ID to Update");
		       				int jobId1 = scanner.nextInt();
		            	   System.out.println("Enter Company's ID to Update");
		       				int compId1 = scanner.nextInt();
		       				JobInterface jobInterface2 = new JobInterfaceImpl();
		       				jobInterface2.updateJobDetails(jobId1, compId1);
		            	   break;
		               case 6:
		            	   System.out.println("Enter Job's ID to Delete");
		       				int jId = scanner.nextInt();
		            	   JobInterface jobInterface1 = new JobInterfaceImpl();
			            	  jobInterface1.deleteJobDetails(jId);
		            	   break;
		               case 7:
		            	   CandidateInterface candidateInterface1 = new CandidateInterfaceImpl();
		            	   candidateInterface1.viewCandidates();
		            	   break;
		               case 8:
		            	   CandidateInterface candidateInterface2 = new CandidateInterfaceImpl();
		            	   candidateInterface2.applyFilterToCandidates();
		            	   break;
		               default: 
		            	   if(op1 == 0) {
	            		   System.out.println("Company Module Terminated");
	            	   }
	            	   else
	            	   System.out.println("Invalid Option");	
		          
		               
		               
		               }
		             
		               }while(op1!=0);
		    	   
		    	   
		    	   break;
		       case 3:
		    	   do {
			    	   System.out.println("1: Add Candidate Details  ");
			           System.out.println("2: Update Candidate Details  ");
			           System.out.println("3: Delete Candidate Details ");
			           System.out.println("4: View all Jobs");
			           System.out.println("5: View Jobs by preferences");
			           System.out.println("0: EXIT CANDIDATE");
			           
			           System.out.println("Enter option of your choice");
			           op1 = Integer.parseInt(bufferedReader.readLine());
			               switch(op1)
			               {
			               case 1:
			            	   CandidateInterface candidateInterface = new CandidateInterfaceImpl();
			            	   candidateInterface.addCandidateDetails();
			               break;
			               case 2:
			            	   System.out.println("Enter Candidate's ID to Update");
			       				int canId = scanner.nextInt();
			            	   CandidateInterface candidateInterface1 = new CandidateInterfaceImpl();
			            	   candidateInterface1.updateCandidateDetails(canId);
			            	   
			               break;
			               case 3:
			            	   System.out.println("Enter Candidate's ID to Delete");
			       				int canId1 = scanner.nextInt();
			       				CandidateInterface candidateInterface2 = new CandidateInterfaceImpl();
			       				candidateInterface2.deleteCandidateDetails(canId1);
			               break;
			               case 4:
			            	   JobInterface jobInterface = new JobInterfaceImpl();
			            	   jobInterface.viewJobDetails();
			               break;
			               case 5:
			            	   JobInterface jobInterface1 = new JobInterfaceImpl();
			            	   jobInterface1.jobFilterByPreference();
			            	   break;

			               default:  
			            	   if(op1 == 0) {
		            		   System.out.println("Candidate Module Terminated");
		            	   }
		            	   else
		            	   System.out.println("Invalid Option");	
			          
			               
			               
			               }
			             
			               }while(op1!=0);
			    	   
			    	   
			    	   break;
		       default :
		    	   if(op == 0) {
            		   System.out.println("Main Menu Terminated");
            	   }
            	   else
            	   System.out.println("Invalid Option");	
		       }
		    
				}while(op != 0);
			}

		

}


