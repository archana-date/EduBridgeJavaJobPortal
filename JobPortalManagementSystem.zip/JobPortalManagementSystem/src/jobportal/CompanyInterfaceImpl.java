package jobportal;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.ListIterator;
import java.util.Scanner;

public class CompanyInterfaceImpl implements CompanyInterface{
	Scanner scanner = new Scanner(System.in);
	File companyFile = new File("company.txt");
	ArrayList<Company> companyList = new ArrayList<Company>();
	ObjectOutputStream oos = null; 
	ObjectInputStream ois = null;
	ListIterator li = null;

		
	@Override
	public void addCompanyDescription() throws Exception {
		// TODO Auto-generated method stub
		System.out.println("Enter Company's ID");
		int companyId = scanner.nextInt();
		System.out.println("Enter Company's Name");
		String companyName = scanner.next();
		System.out.println("Enter Company's Address");
		String companyAddress = scanner.next();
		System.out.println("Enter Company's Email");
		String companyEmail = scanner.next();
		System.out.println("Enter Company's Phone Number");
		String companyPhone = scanner.next();
		try {
			if(companyFile.isFile()) {
				ois = new ObjectInputStream(new FileInputStream(companyFile));
				companyList = (ArrayList<Company>) ois.readObject();
				ois.close();
			}
			
		}
		catch(Exception e) {
			System.out.println("Exception is"+e);
		}
		companyList.add(new Company(companyId,companyName,companyAddress,companyEmail,companyPhone));
		//System.out.println(companyList);
		try {
			
			oos =new ObjectOutputStream(new FileOutputStream(companyFile));
			oos.writeObject(companyList);
			oos.close();
		}
		catch(Exception e) {
			System.out.println("Exception is"+e);
		}
	}
	@Override
	public void viewCompanies() throws Exception {
		// TODO Auto-generated method stub
		try {
			if(companyFile.isFile()) {
				ois = new ObjectInputStream(new FileInputStream(companyFile));
				companyList = (ArrayList<Company>) ois.readObject();
				ois.close();
			}
			System.out.println("-------------------------------------------------");
			li = companyList.listIterator();
			while(li.hasNext()) {
				System.out.println(li.next());
			}
			System.out.println("-------------------------------------------------");
		}
		catch(Exception e) {
			System.out.println("Exception is"+e);
		}
		
	}





	@Override
	public void updateCompanyDescription(int companyId) throws Exception {
		// TODO Auto-generated method stub
		try {
			if(companyFile.isFile()) {
				ois = new ObjectInputStream(new FileInputStream(companyFile));
				companyList = (ArrayList<Company>) ois.readObject();
				ois.close();
			}
			boolean found = false;
			
			
			System.out.println("-------------------------------------------------");
			li = companyList.listIterator();
			while(li.hasNext()) {
				Company company = (Company)li.next();
				if(company.getCompanyId() == companyId ) {
					li.remove();
					System.out.println("Enter Company's Name");
					String companyName = scanner.next();
					System.out.println("Enter Company's Address");
					String companyAddress = scanner.next();
					System.out.println("Enter Company's Email");
					String companyEmail = scanner.next();
					System.out.println("Enter Company's Phone Number");
					String companyPhone = scanner.next();
					
				

					li.add(new Company(companyId,companyName,companyAddress,companyEmail,companyPhone));
					found = true;
				}
			}
			System.out.println("-------------------------------------------------");
			if(found == true) {
				
				try {
					System.out.println("Record Updated");
					oos =new ObjectOutputStream(new FileOutputStream(companyFile));
					oos.writeObject(companyList);
					oos.close();
				}
				catch(Exception e) {
					System.out.println("Exception is"+e);
				}
			}
			else {
				System.out.println("Record Not Exist");
			}
		}
		catch(Exception e) {
			System.out.println("Exception is"+e);
		}
		
	}

	

	@Override
	public void deleteCompanyDescription(int companyId) throws Exception {
		// TODO Auto-generated method stub
		try {
			if(companyFile.isFile()) {
				ois = new ObjectInputStream(new FileInputStream(companyFile));
				companyList = (ArrayList<Company>) ois.readObject();
				ois.close();
			}
			boolean found = false;
			
			
			
			li = companyList.listIterator();
			while(li.hasNext()) {
				Company company = (Company)li.next();
				if(company.getCompanyId() == companyId ) {
					li.remove();
					found = true;
				}
			}
			
			if(found == true) {
				try {
					System.out.println("Record Deleted");
					oos =new ObjectOutputStream(new FileOutputStream(companyFile));
					oos.writeObject(companyList);
					oos.close();
				}
				catch(Exception e) {
					System.out.println("Exception is"+e);
				}
			}
			else {
				System.out.println("Record Not Exist");
			}
		}
		catch(Exception e) {
			System.out.println("Exception is"+e);
		}
		
		
	}
}
