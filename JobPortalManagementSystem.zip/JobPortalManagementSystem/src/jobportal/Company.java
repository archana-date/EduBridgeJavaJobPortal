package jobportal;

import java.io.Serializable;

public class Company implements Serializable{
	private int companyId;
	private String companyName;
	private String companyAddress;
	private String companyEmail;
	private String companyPhoneNo;
	public Company() {
		
	}
	public Company(int companyId, String companyName, String companyAddress, String companyEmail,
			String companyPhoneNo) {
		super();
		this.companyId = companyId;
		this.companyName = companyName;
		this.companyAddress = companyAddress;
		this.companyEmail = companyEmail;
		this.companyPhoneNo = companyPhoneNo;
	}
	public int getCompanyId() {
		return companyId;
	}
	public void setCompanyId(int companyId) {
		this.companyId = companyId;
	}
	public String getCompanyName() {
		return companyName;
	}
	public void setCompanyName(String companyName) {
		this.companyName = companyName;
	}
	public String getCompanyAddress() {
		return companyAddress;
	}
	public void setCompanyAddress(String companyAddress) {
		this.companyAddress = companyAddress;
	}
	public String getCompanyEmail() {
		return companyEmail;
	}
	public void setCompanyEmail(String companyEmail) {
		this.companyEmail = companyEmail;
	}
	public String getCompanyPhoneNo() {
		return companyPhoneNo;
	}
	public void setCompanyPhoneNo(String companyPhoneNo) {
		this.companyPhoneNo = companyPhoneNo;
	}
	@Override
	public String toString() {
		return  companyId + " " + companyName + " " + companyAddress + " " + companyEmail + " " + companyPhoneNo;
	}
	
	
}