package jobportal;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.ListIterator;
import java.util.Scanner;

public class CandidateInterfaceImpl implements CandidateInterface{
	Scanner scanner = new Scanner(System.in);
	File candidateFile = new File("candidate.txt");
	ArrayList<Candidate> candidateList = new ArrayList<Candidate>();
	ObjectOutputStream oos = null; 
	ObjectInputStream ois = null;
	ListIterator li = null;

	@Override
	public void addCandidateDetails() throws Exception {
		// TODO Auto-generated method stub
		System.out.println("Enter Candidate's ID");
		int candidateId = scanner.nextInt();
		
		System.out.println("Enter Candidate's Name");
		String candidateName = scanner.next();
		
		System.out.println("Enter Candidate's Address");
		String candidateAddress = scanner.next();
		
		System.out.println("Enter Candidate's Phone Number");
		String candidatePhone = scanner.next();
		
		System.out.println("Enter Candidate's Email");
		String candidateEmail = scanner.next();
		
		System.out.println("Enter Candidate's Latest Education");
		String candidateEducation = scanner.next();
		
		System.out.println("Enter Candidate's Experience in year");
		int candidateExperience = scanner.nextInt();
		
		System.out.println("Enter Candidate's most fluent offical language");
		String candidateLanguageKnown = scanner.next();
		
		System.out.println("Enter Candidate's Job Preference");
		String candidatePreference = scanner.next();

		

		
		try {
			if(candidateFile.isFile()) {
				ois = new ObjectInputStream(new FileInputStream(candidateFile));
				candidateList = (ArrayList<Candidate>) ois.readObject();
				ois.close();
			}
			
		}
		catch(Exception e) {
			System.out.println("Exception is"+e);
		}
		candidateList.add(new Candidate(candidateId,candidateName,candidateAddress,candidatePhone,candidateEmail,candidateEducation,candidateExperience,candidateLanguageKnown,candidatePreference));
		//System.out.println(companyList);
		try {
			
			oos =new ObjectOutputStream(new FileOutputStream(candidateFile));
			oos.writeObject(candidateList);
			oos.close();
		}
		catch(Exception e) {
			System.out.println("Exception is"+e);
		}
	}

	@Override
	public void viewCandidates() throws Exception {
		// TODO Auto-generated method stub
		try {
			if(candidateFile.isFile()) {
				ois = new ObjectInputStream(new FileInputStream(candidateFile));
				candidateList = (ArrayList<Candidate>) ois.readObject();
				ois.close();
			}
			System.out.println("-------------------------------------------------");
			li = candidateList.listIterator();
			while(li.hasNext()) {
				System.out.println(li.next());
			}
			System.out.println("-------------------------------------------------");
		}
		catch(Exception e) {
			System.out.println("Exception is"+e);
		}
		
		
	}

	@Override
	public void updateCandidateDetails(int candidateId) throws Exception {
		// TODO Auto-generated method stub
		
		try {
			if(candidateFile.isFile()) {
				ois = new ObjectInputStream(new FileInputStream(candidateFile));
				candidateList = (ArrayList<Candidate>) ois.readObject();
				ois.close();
			}
			boolean found = false;
			
			
			System.out.println("-------------------------------------------------");
			li = candidateList.listIterator();
			while(li.hasNext()) {
				Candidate candidate = (Candidate)li.next();
				if(candidate.getCandidateId() == candidateId ) {
					li.remove();
					System.out.println("Enter Candidate's Name");
					String candidateName = scanner.next();
					
					System.out.println("Enter Candidate's Address");
					String candidateAddress = scanner.next();
					
					System.out.println("Enter Candidate's Phone Number");
					String candidatePhone = scanner.next();
					
					System.out.println("Enter Candidate's Email");
					String candidateEmail = scanner.next();
					
					System.out.println("Enter Candidate's Latest Education");
					String candidateEducation = scanner.next();
					
					System.out.println("Enter Candidate's Experience in year");
					int candidateExperience = scanner.nextInt();
					
					System.out.println("Enter Candidate's most fluent offical language");
					String candidateLanguageKnown = scanner.next();
					
					System.out.println("Enter Candidate's Job Preference");
					String candidatePreference = scanner.next();
					
				

					li.add(new Candidate(candidateId,candidateName,candidateAddress,candidatePhone,candidateEmail,candidateEducation,candidateExperience,candidateLanguageKnown,candidatePreference));
					found = true;
				}
			}
			System.out.println("-------------------------------------------------");
			if(found == true) {
				
				try {
					System.out.println("Record Updated");
					oos =new ObjectOutputStream(new FileOutputStream(candidateFile));
					oos.writeObject(candidateList);
					oos.close();
				}
				catch(Exception e) {
					System.out.println("Exception is"+e);
				}
			}
			else {
				System.out.println("Record Not Exist");
			}
		}
		catch(Exception e) {
			System.out.println("Exception is"+e);
		}
		
	}

	@Override
	public void deleteCandidateDetails(int candidateId) throws Exception {
		// TODO Auto-generated method stub
		try {
			if(candidateFile.isFile()) {
				ois = new ObjectInputStream(new FileInputStream(candidateFile));
				candidateList = (ArrayList<Candidate>) ois.readObject();
				ois.close();
			}
			boolean found = false;
			
			
			System.out.println("-------------------------------------------------");
			li = candidateList.listIterator();
			while(li.hasNext()) {
				Candidate candidate = (Candidate)li.next();
				if(candidate.getCandidateId() == candidateId ) {
					li.remove();
					found = true;
				}
			}
			System.out.println("-------------------------------------------------");
			if(found == true) {
				
				try {
					System.out.println("Record Deleted");
					oos =new ObjectOutputStream(new FileOutputStream(candidateFile));
					oos.writeObject(candidateList);
					oos.close();
				}
				catch(Exception e) {
					System.out.println("Exception is"+e);
				}
			}
			else {
				System.out.println("Record Not Exist");
			}
		}
		catch(Exception e) {
			System.out.println("Exception is"+e);
		}
		
	}

	@Override
	public void applyFilterToCandidates() throws Exception {
		// TODO Auto-generated method stub
		try {
			if(candidateFile.isFile()) {
				ois = new ObjectInputStream(new FileInputStream(candidateFile));
				candidateList = (ArrayList<Candidate>) ois.readObject();
				ois.close();
			}
			boolean found = false;
		
			System.out.println("Enter the candidate Qualification you want");
			String qual = scanner.next();
			System.out.println("Enter the candidate Experience you want");
			int expe = scanner.nextInt();
			System.out.println("Enter the candidate Preference you want");
			String pre = scanner.next();
			
			
			System.out.println("-------------------------------------------------");
			li = candidateList.listIterator();

			while(li.hasNext()) {

				Candidate candidate = (Candidate)li.next();
				if(candidate.getCandidateExperience() == expe && (candidate.getCandidateEducation()).equals(qual) && (candidate.getCandidatePreference()).equals(pre)) {
					System.out.println(candidate);
					found = true;
				}
				
			}
			
			System.out.println("-------------------------------------------------");
			if(found == true) {
				
				
			
			}
			else {
				System.out.println("Record Not Exist");
			}
		}
		catch(Exception e) {
			System.out.println("Exception is"+e);
		}
		
		
	}

	

}
