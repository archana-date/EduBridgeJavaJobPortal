package jobportal;

public interface JobInterface {
	void addJobDetails() throws Exception;
	void updateJobDetails(int jobId,int companyId) throws Exception;
	void deleteJobDetails(int jobId) throws Exception;
	void viewJobDetails() throws Exception;
	void jobFilterByPreference() throws Exception;
}
