package jobportal;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.ArrayList;
import java.util.ListIterator;
import java.util.Scanner;

public class JobInterfaceImpl implements JobInterface{
	Scanner scanner = new Scanner(System.in);
	File companyFile = new File("company.txt");
	ArrayList<Company> companyList = new ArrayList<Company>();
	ObjectOutputStream oos = null; 
	ObjectInputStream ois = null;
	ListIterator li = null;
	
	File jobFile = new File("job.txt");
	ArrayList<Job> jobList = new ArrayList<Job>();
	ObjectOutputStream oos1 = null; 
	ObjectInputStream ois1 = null;
	ListIterator li1 = null;
	@Override
	public void addJobDetails() throws Exception {
		// TODO Auto-generated method stub
		System.out.println("Enter Company ID for verification");
		int companyId = scanner.nextInt();
		try {
			if(companyFile.isFile()) {
				ois = new ObjectInputStream(new FileInputStream(companyFile));
				companyList = (ArrayList<Company>) ois.readObject();
				ois.close();
			}
			boolean found = false;			
			li = companyList.listIterator();
			while(li.hasNext()) {
				Company company = (Company)li.next();
				if(company.getCompanyId() == companyId ) {
					
					found = true;
				}
			}
			
			if(found == true) {
				try {
					System.out.println("Enter number of jobs you want to Post");
					int jobNo = scanner.nextInt();
					for(int i=0;i<jobNo;i++) {
						System.out.println("Enter Job's ID");
						int jobId = scanner.nextInt();
						System.out.println("Enter Job's Name");
						String jobName = scanner.next();
						System.out.println("Enter Educational Requirement");
						String jobEducationRequirement = scanner.next();
						System.out.println("Enter Experience Requirement");
						int jobExperienceRequirement = scanner.nextInt();
						System.out.println("Enter Languages Requirement");
						String jobLanguagesRequirement = scanner.next();
						System.out.println("Enter Job Category");
						String jobCategory = scanner.next();
						System.out.println("Enter your company ID");
						int companyId1 = scanner.nextInt();
						
						try {
							if(jobFile.isFile()) {
								ois1 = new ObjectInputStream(new FileInputStream(jobFile));
								jobList = (ArrayList<Job>) ois1.readObject();
								ois1.close();
							}
							
						}
						catch(Exception e) {
							System.out.println("Exception is"+e);
						}
						jobList.add(new Job(jobId,jobName,jobEducationRequirement,jobExperienceRequirement,jobLanguagesRequirement,jobCategory,companyId1));
					}
					
					
					//System.out.println(companyList);
					try {
						
						oos1 =new ObjectOutputStream(new FileOutputStream(jobFile));
						oos1.writeObject(jobList);
						oos1.close();
					}
					catch(Exception e) {
						System.out.println("Exception is"+e);
					}
				}
				catch(Exception e) {
					System.out.println("Exception is"+e);
				}
			}
			else {
				System.out.println("Record Not Exist");
			}
		}
		catch(Exception e) {
			System.out.println("Exception is"+e);
		}
		
		
		
		
	}

	@Override
	public void updateJobDetails(int jobId, int companyId) throws Exception {
		// TODO Auto-generated method stub
		try {
			if(jobFile.isFile()) {
				ois1 = new ObjectInputStream(new FileInputStream(jobFile));
				jobList = (ArrayList<Job>) ois1.readObject();
				ois1.close();
			}
			boolean found = false;
			
			
			System.out.println("-------------------------------------------------");
			li = jobList.listIterator();
			while(li.hasNext()) {
				Job job = (Job)li.next();
				if(job.getJobId() == jobId && job.getCompanyId() == companyId) {
					li.remove();
					System.out.println("Enter Job's Name");
					String jobName = scanner.next();
					System.out.println("Enter Educational Requirement");
					String jobEducationRequirement = scanner.next();
					System.out.println("Enter Experience Requirement");
					int jobExperienceRequirement = scanner.nextInt();
					System.out.println("Enter Languages Requirement");
					String jobLanguagesRequirement = scanner.next();
					System.out.println("Enter Job Category");
					String jobCategory = scanner.next();
					
					
				

					li.add(new Job(jobId,jobName,jobEducationRequirement,jobExperienceRequirement,jobLanguagesRequirement,jobCategory,companyId));
					found = true;
				}
			}
			System.out.println("-------------------------------------------------");
			if(found == true) {
				
				try {
					System.out.println("Record Updated");
					oos1 =new ObjectOutputStream(new FileOutputStream(jobFile));
					oos1.writeObject(jobList);
					oos1.close();
				}
				catch(Exception e) {
					System.out.println("Exception is"+e);
				}
			}
			else {
				System.out.println("Record Not Exist");
			}
		}
		catch(Exception e) {
			System.out.println("Exception is"+e);
		}
		
	}

	@Override
	public void deleteJobDetails(int jobId) throws Exception {
		// TODO Auto-generated method stub
		try {
			if(jobFile.isFile()) {
				ois1 = new ObjectInputStream(new FileInputStream(jobFile));
				jobList = (ArrayList<Job>) ois1.readObject();
				ois1.close();
			}
			boolean found = false;
			
			
			
			li = jobList.listIterator();
			while(li.hasNext()) {
				Job job = (Job)li.next();
				if(job.getJobId() == jobId ) {
					li.remove();
					found = true;
				}
			}
			
			if(found == true) {
				try {
					System.out.println("Record Deleted");
					oos1 =new ObjectOutputStream(new FileOutputStream(jobFile));
					oos1.writeObject(jobList);
					oos1.close();
				}
				catch(Exception e) {
					System.out.println("Exception is"+e);
				}
			}
			else {
				System.out.println("Record Not Exist");
			}
		}
		catch(Exception e) {
			System.out.println("Exception is"+e);
		}
	}

	@Override
	public void viewJobDetails() throws Exception {
		// TODO Auto-generated method stub
		try {
			if(jobFile.isFile()) {
				ois1 = new ObjectInputStream(new FileInputStream(jobFile));
				jobList = (ArrayList<Job>) ois1.readObject();
				ois1.close();
			}
			System.out.println("-------------------------------------------------");
			li = jobList.listIterator();
			while(li.hasNext()) {
				System.out.println(li.next());
			}
			System.out.println("-------------------------------------------------");
		}
		catch(Exception e) {
			System.out.println("Exception is"+e);
		}
		
	}

	@Override
	public void jobFilterByPreference() throws Exception {
		// TODO Auto-generated method stub
		try {
			if(jobFile.isFile()) {
				ois1 = new ObjectInputStream(new FileInputStream(jobFile));
				jobList = (ArrayList<Job>) ois1.readObject();
				ois1.close();
			}
			boolean found = false;
		
			System.out.println("Enter your Preference to view job");
			String pre = scanner.next();
			
			
			
			System.out.println("-------------------------------------------------");
			li = jobList.listIterator();

			while(li.hasNext()) {

				Job job = (Job)li.next();
				if((job.getJobCategory()).equals(pre)) {
					System.out.println(job);
					found = true;
				}
				
			}
			
			System.out.println("-------------------------------------------------");
			if(found == true) {
				
				
			
			}
			else {
				System.out.println("Record Not Exist");
			}
		}
		catch(Exception e) {
			System.out.println("Exception is"+e);
		}
	}

}
