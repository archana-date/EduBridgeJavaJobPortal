package jobportal;

import java.io.Serializable;

public interface CompanyInterface{
	void addCompanyDescription() throws Exception;
	void viewCompanies() throws Exception;
	void updateCompanyDescription(int companyId) throws Exception;
	void deleteCompanyDescription(int companyId) throws Exception;
}
