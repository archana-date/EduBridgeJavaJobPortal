package jobportal;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.ArrayList;
import java.util.ListIterator;
import java.util.Scanner;

public class AdminInterfaceImpl implements AdminInterface{
	
	Scanner scanner = new Scanner(System.in);
	File adminFile = new File("admin.txt");
	ArrayList<Admin> adminList = new ArrayList<Admin>();
	ObjectOutputStream oos = null; 
	ObjectInputStream ois = null;
	ListIterator li = null;
	
	@Override
	public void addAdmin() throws Exception {
		// TODO Auto-generated method stub
		System.out.println("Enter Admin's ID");
		int adminId = scanner.nextInt();
		System.out.println("Enter Admin's Name");
		String adminName = scanner.next();
		System.out.println("Enter Admin's Password");
		String adminPassword = scanner.next();

		try {
			if(adminFile.isFile()) {
				ois = new ObjectInputStream(new FileInputStream(adminFile));
				adminList = (ArrayList<Admin>) ois.readObject();
				ois.close();
			}
			
		}
		catch(Exception e) {
			System.out.println("Exception is"+e);
		}
		adminList.add(new Admin(adminId,adminName,adminPassword));
		//System.out.println(companyList);
		try {
			
			oos =new ObjectOutputStream(new FileOutputStream(adminFile));
			oos.writeObject(adminList);
			oos.close();
		}
		catch(Exception e) {
			System.out.println("Exception is"+e);
		}
		
	}

	@Override
	public void viewAdmin() throws Exception {
		// TODO Auto-generated method stub
		try {
			if(adminFile.isFile()) {
				ois = new ObjectInputStream(new FileInputStream(adminFile));
				adminList = (ArrayList<Admin>) ois.readObject();
				ois.close();
			}
			System.out.println("-------------------------------------------------");
			li = adminList.listIterator();
			while(li.hasNext()) {
				System.out.println(li.next());
			}
			System.out.println("-------------------------------------------------");
		}
		catch(Exception e) {
			System.out.println("Exception is"+e);
		}
	}

	@Override
	public void updateAdmin(int adminId) throws Exception {
		// TODO Auto-generated method stub
		try {
			if(adminFile.isFile()) {
				ois = new ObjectInputStream(new FileInputStream(adminFile));
				adminList = (ArrayList<Admin>) ois.readObject();
				ois.close();
			}
			boolean found = false;
			
			
			System.out.println("-------------------------------------------------");
			li = adminList.listIterator();
			while(li.hasNext()) {
				Admin admin = (Admin)li.next();
				if(admin.getAdminId() == adminId ) {
					li.remove();
					System.out.println("Enter Admin's Name");
					String adminName = scanner.next();
					System.out.println("Enter Admin's Password");
					String adminPassword = scanner.next();
					
				

					li.add(new Admin(adminId,adminName,adminPassword));
					found = true;
				}
			}
			System.out.println("-------------------------------------------------");
			if(found == true) {
				
				try {
					System.out.println("Record Updated");
					oos =new ObjectOutputStream(new FileOutputStream(adminFile));
					oos.writeObject(adminList);
					oos.close();
				}
				catch(Exception e) {
					System.out.println("Exception is"+e);
				}
			}
			else {
				System.out.println("Record Not Exist");
			}
		}
		catch(Exception e) {
			System.out.println("Exception is"+e);
		}
	}

	@Override
	public void deleteAdmin(int adminId) throws Exception {
		// TODO Auto-generated method stub
		try {
			if(adminFile.isFile()) {
				ois = new ObjectInputStream(new FileInputStream(adminFile));
				adminList = (ArrayList<Admin>) ois.readObject();
				ois.close();
			}
			boolean found = false;
			
			
			
			li = adminList.listIterator();
			while(li.hasNext()) {
				Admin admin = (Admin)li.next();
				if(admin.getAdminId() == adminId ) {
					li.remove();
					found = true;
				}
			}
			
			if(found == true) {
				try {
					System.out.println("Record Deleted");
					oos =new ObjectOutputStream(new FileOutputStream(adminFile));
					oos.writeObject(adminList);
					oos.close();
				}
				catch(Exception e) {
					System.out.println("Exception is"+e);
				}
			}
			else {
				System.out.println("Record Not Exist");
			}
		}
		catch(Exception e) {
			System.out.println("Exception is"+e);
		}
	}

	
		
	

}
