package jobportal;

import java.io.Serializable;

public class Job implements Serializable{
	private int jobId;
	private String jobName;
	private String jobEducationRequirement;
	private int jobExperienceRequirement;
	private String jobLanguagesRequirement;
	private String jobCategory;
	private int companyId;
	
	public Job(int jobId, String jobName, String jobEducationRequirement, int jobExperienceRequirement,
			String jobLanguagesRequirement, String jobCategory, int companyId) {
		super();
		this.jobId = jobId;
		this.jobName = jobName;
		this.jobEducationRequirement = jobEducationRequirement;
		this.jobExperienceRequirement = jobExperienceRequirement;
		this.jobLanguagesRequirement = jobLanguagesRequirement;
		this.jobCategory = jobCategory;
		this.companyId = companyId;
	}

	public int getJobId() {
		return jobId;
	}

	public void setJobId(int jobId) {
		this.jobId = jobId;
	}

	public String getJobName() {
		return jobName;
	}

	public void setJobName(String jobName) {
		this.jobName = jobName;
	}

	public String getJobEducationRequirement() {
		return jobEducationRequirement;
	}

	public void setJobEducationRequirement(String jobEducationRequirement) {
		this.jobEducationRequirement = jobEducationRequirement;
	}

	public int getJobExperienceRequirement() {
		return jobExperienceRequirement;
	}

	public void setJobExperienceRequirement(int jobExperienceRequirement) {
		this.jobExperienceRequirement = jobExperienceRequirement;
	}

	public String getJobLanguagesRequirement() {
		return jobLanguagesRequirement;
	}

	public void setJobLanguagesRequirement(String jobLanguagesRequirement) {
		this.jobLanguagesRequirement = jobLanguagesRequirement;
	}

	public String getJobCategory() {
		return jobCategory;
	}

	public void setJobCategory(String jobCategory) {
		this.jobCategory = jobCategory;
	}
	public int getCompanyId() {
		return companyId;
	}

	public void setCompanyId(int companyId) {
		this.companyId = companyId;
	}

	@Override
	public String toString() {
		return  jobId + " " + jobName + " " + jobEducationRequirement
				+ " " + jobExperienceRequirement + " "
				+ jobLanguagesRequirement + " " + jobCategory + " " + companyId;
	}
	
	
}