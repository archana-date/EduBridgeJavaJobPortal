package jobportal;



public interface AdminInterface {
	void addAdmin() throws Exception;
	void viewAdmin() throws Exception;
	void updateAdmin(int adminId) throws Exception;
	void deleteAdmin(int adminId) throws Exception;
}
