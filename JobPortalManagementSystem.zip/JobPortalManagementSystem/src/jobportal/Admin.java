package jobportal;

import java.io.Serializable;

public class Admin implements Serializable{
	int adminId;
	String adminName;
	String adminPassword;
	public Admin(int adminId, String adminName, String adminPassword) {
		super();
		this.adminId = adminId;
		this.adminName = adminName;
		this.adminPassword = adminPassword;;
	}
	public int getAdminId() {
		return adminId;
	}
	public void setAdminId(int adminId) {
		this.adminId = adminId;
	}
	public String getAdminName() {
		return adminName;
	}
	public void setAdminName(String adminName) {
		this.adminName = adminName;
	}
	public String getadminPassword() {
		return adminPassword;
	}
	public void setadminPassword(String adminPassword) {
		this.adminPassword = adminPassword;
	}
	@Override
	public String toString() {
		return  adminId +" " + adminName + " " +adminPassword;
	}
	

}
